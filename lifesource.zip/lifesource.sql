
-- Database: `lifesource`
--

-- --------------------------------------------------------

--
-- Table structure for table `donors`
--

CREATE TABLE IF NOT EXISTS `donors` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fname` varchar(45) NOT NULL,
  `mname` varchar(30) NULL,
  `lname` varchar(45) NOT NULL,
  
  `sex` varchar(10) NOT NULL,
  `b_type` varchar(2) NOT NULL,
  `bday` date NOT NULL,
  `h_address` varchar(50) NOT NULL,
  `city` varchar(30) NOT NULL,
  `don_date` date NOT NULL,
  `stats` text NOT NULL,
  `temp` varchar(10) NOT NULL,
  `pulse` varchar(10) NOT NULL,
  `bp` varchar(10) NOT NULL,
  `weight` int(11) NOT NULL,
  `hemoglobin` varchar(25) NOT NULL,
  `hbsag` varchar(10) NOT NULL,
  `aids` varchar(15) NOT NULL,
  `malaria_smear` varchar(20) NOT NULL,
  `hematocrit` varchar(15) NOT NULL,
  `phone` varchar(10) DEFAULT NULL,
  `mobile` varchar(11) NOT NULL,
  PRIMARY KEY (`id`)
)

--
-- Dumping data for table `donors`
--

INSERT INTO `donors` (`id`, `fname`, `mname`, `lname`, `sex`, `b_type`, `bday`, `h_address`, `city`, `don_date`, `stats`, `temp`, `pulse`, `bp`, `weight`, `hemoglobin`, `hbsag`, `aids`, `malaria_smear`, `hematocrit`, `phone`, `mobile`) VALUES
(10, 'Ankita', '', 'ganiger', 'female', 'B+', '1999-06-6', '1234,Soldevnhalli ','Bangalore', '2020-06-16', 'Normal', '30', '60', '80 | 120', 64, '16 - 18 gm/dl', 'Negative', 'Negative', 'Negative', '45 - 62%', '254619', '8951436013'),
(20, 'Sheetal', '', 'h', 'female', 'A+', '1999-02-02', '234,Yellenchanhalli',' Bangalore', '2020-04-18', 'Normal', '30', '60', '80 | 120', 64, '16 - 18 gm/dl', 'Negative', 'Negative', 'Negative', '45 - 62%', '', '8602042302');


-- --------------------------------------------------------

--
-- Table structure for table `employees`
--

CREATE TABLE IF NOT EXISTS `employees` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `f_name` varchar(35) NOT NULL,
  `m_name` varchar(15) DEFAULT NULL,
  `l_name` varchar(35) NOT NULL,
  `username` varchar(15) NOT NULL,
  `password` varchar(15) NOT NULL,
  `b_day` date NOT NULL,
 
  `designation` varchar(35) NOT NULL,
  `landline` varchar(10) DEFAULT NULL,
  `mobile_nr` varchar(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),

) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=18 ;

--
-- Dumping data for table `employees`
--

INSERT INTO `employees` (`id`, `f_name`, `m_name`, `l_name`, `username`, `password`, `b_day`,  `designation`, `landline`, `mobile_nr`) VALUES
(10, 'Akshata', '', 'Handigund', 'aksha', '123', '1999-06-6',  'Student', ", '9827983762');

-- --------------------------------------------------------

--
-- Table structure for table `users`

CREATE TABLE IF NOT EXISTS `users` (
  
  `first_name` varchar(50) NOT NULL,
  `last_name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(11) NOT NULL ,
  `dob` date NOT NULL,
  `gender` varchar(10) NOT NULL,
  `b_type` varchar(5) NOT NULL,
  `address` varchar(200) NOT NULL,
  `city` varchar(100) NOT NULL,
  `mobile` varchar(13) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`password`),
  UNIQUE KEY `email` (`email`)
)  ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` ( `first_name`, `last_name`, `email`,`password`, `dob`, `gender`, `b_type`, `address`, `city`, `mobile`, `created_at`) VALUES
( 'Anusha', 'Agrawal', 'ansuahaagrawal007@gmail.com','anusha', '1999-07-16', 'Female', 'O+', 'KebColony', 'Mysore', '9827983762', '2020-08-19 17:12:26'),
( 'Diksha', 'Gupta', 'diksha24gupta24@gmail.com','diksha', '1994-09-24', 'Female', 'B+', 'State Bank Colony', 'Bangalore', '8269036096', '2020-08-28 10:08:46'),
( 'Vishal', 'Rathod', 'vishalrathod@gmail.com','vishal' '2000-02-15', 'Male', 'O-',  'Vijaynagar', 'Shimoga', '8871479418', '2020-04-30 06:27:06');
